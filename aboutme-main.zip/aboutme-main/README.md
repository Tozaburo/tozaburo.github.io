# 【注意】tozaburo.github.io に 移行しました。もう更新されません。
### きっとtozaburo.github.ioはもっと楽しいよ。

# やぁ。
---
この度は大変申し訳ありませんでした。
mdの書き方が知らないふりをして書かなかったのは~~面倒~~ ~~時間がなかった~~ ~~気づかなかった~~からです。
>取り消し線を乱用すればするほど良い

---
## さて
###### このgithubページは自分のhtml練習と自己紹介を兼ねたものです。気楽に見てください。
###### 公開しているものは[ここ](https://https://tozaburo.github.io/aboutme/sitemap)で全てバレます。（何ならここまで来るところで見ましたよね？）
---
## 最後に
まだ全て下手~~くそ~~です。htmlは狂乱、cssは醜悪、jsは蕪雑です。でも、成長はしています。なので温かい目で見てください。

以上。




# mdってこう書くの？
<!--
**Tozaburo/tozaburo** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
