var lang = window.navigator.language;

window.addEventListener("DOMContentLoaded", function () {
  // clang();
});

function clang() {
  if (lang != "ja") {
    document.querySelector(".main").innerHTML = `
		
    `;
  }
}
